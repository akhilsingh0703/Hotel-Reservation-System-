## Type of Change
<!-- Replace the space with an 'x' in the appropriate box and delete other options. -->
<!-- example: [x] Feat: added new route for /login page -->
- [ ] Bug: [Title]
- [ ] Feat: [Title]
- [ ] Doc: [Title]
- [ ] Test: [Title]
- [ ] CI: [Title]

## Description
<!-- Briefly describe the changes you've made. -->

## Linked Issue
<!-- If applicable, link the issue number that this PR closes. Use the format: #ISSUE_NUMBER -->

## Screenshots
<!-- Attach any screenshots or visuals that highlight the changes. -->

## Tests
<!-- Describe the tests you've performed to ensure the functionality is working as expected. -->
